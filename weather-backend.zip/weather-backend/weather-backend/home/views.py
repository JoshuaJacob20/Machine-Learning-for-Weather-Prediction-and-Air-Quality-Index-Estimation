from django.shortcuts import HttpResponse
import datetime as dt
import requests
import json
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import numpy as np
from django.http import JsonResponse



#Constant variables
BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"
API_KEY = "0bd3c27df486a61e90b12d27d6ff4ec2"
air_pollution_url = 'http://api.openweathermap.org/data/2.5/air_pollution'
weather_map_url = 'http://api.openweathermap.org/data/2.5/weather'


# Create your views here.
def index(request):
    return HttpResponse("this is homepage")

def kelvin_to_celsius_fahrenheit(kelvin):
  celsius =kelvin - 273.15
  fahrenheit = celsius * (9/5) +32
  return celsius ,fahrenheit

def weather(request):
    CITY = request.GET.get('city', "bangalore")

    url = BASE_URL + "appid=" + API_KEY + "&q=" + CITY
    response1 = requests.get(url)
    
    # temp_kelvin =response1['main'] ['temp']
    # temp_celsius,temp_fahrenheit = kelvin_to_celsius_fahrenheit(temp_kelvin)
    # print(response1)
    # feels_like_kelvin = response1['main']['temp']
    # feels_like_celsius, feels_like_fahrenheit = kelvin_to_celsius_fahrenheit(feels_like_kelvin)
    # humidity =response1['main']['humidity']
    # description = response1['weather'][0]['description']
    # wind_speed = response1['wind']['speed']
    # sunrise_time = dt.datetime.utcfromtimestamp(response1['sys']['sunrise'] + response1['timezone'])
    # sunset_time = dt.datetime.utcfromtimestamp(response1['sys']['sunset'] + response1['timezone'])
    # return HttpResponse("Temperature in "+CITY+":"+str(temp_celsius)+"°C or "+str(temp_fahrenheit)+"°F\n"
    #                     + "humadity in "+CITY+":"+str(humidity)+"%\n"
    #                     +"wind speed in "+CITY+":"+str(wind_speed)+"m/s\n"
    #                     + "general weather in"+CITY+":"+str(description)+"\n"
    #                     + "Sunrise in "+CITY+" at "+str(sunrise_time)+"local time\n"
    #                     + "Sunset in "+CITY+" at "+str(sunset_time)+" local time\n")
    if response1:
        data = response1.json()
        return JsonResponse(data, safe=False)
    else:
        # Handle errors or return an error message
        return JsonResponse({'error': 'Request failed'}, status=response1)

def pollution(request):
    lattitude = request.GET.get('lat', 12.9762)
    longitude = request.GET.get('lon', 77.6033)
    pollution_params = {'lon': longitude, 'lat': lattitude, 'appid': API_KEY}
    pollution_response = requests.get(air_pollution_url, params=pollution_params)
    if pollution_response:
        data = pollution_response.json()
        return JsonResponse(data, safe=False)
    else:
        # Handle errors or return an error message
        return JsonResponse({'error': 'Request failed'}, status=pollution_response)



def predict(request):
    # Generating dummy data (replace this with your actual dataset)
    X = np.random.rand(100, 3)  # Example weather data (100 samples, 3 features)
    y = np.random.randint(0, 100, 100)  # Example AQI values for the dataset

    # Splitting data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize and fit RandomForestRegressor model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Fetch real-time weather data
    real_time_weather = fetch_weather_data()

    if real_time_weather:
        # Predict Air Quality Index (AQI) using the fetched weather data
        predicted_aqi = predict_aqi(model, real_time_weather)

        if predicted_aqi:
            print('Real-time weather data:', real_time_weather)
            print('Predicted AQI:', predicted_aqi[0])
            resp = {'weather': real_time_weather, 'predict': predicted_aqi[0]}
            return JsonResponse(resp)
        

# Function to predict Air Quality Index (AQI) using RandomForestRegressor
def predict_aqi(model, weather_data):
    # Predict AQI using the weather data
    predicted_aqi = model.predict([list(weather_data.values())])
    return predicted_aqi

def fetch_weather_data():
    # Replace this with your actual implementation to fetch real-time weather data
    # For demonstration purposes, returning a dummy weather data dictionary
    return {'temperature': 25.0, 'humidity': 60.0, 'wind_speed': 10.0}

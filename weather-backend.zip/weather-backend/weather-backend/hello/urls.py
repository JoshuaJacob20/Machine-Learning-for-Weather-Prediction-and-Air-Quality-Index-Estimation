
from django.urls import path
from home import views

urlpatterns = [
    path("",views.index, name='home'),
    path("weather",views.weather, name='weather'),
    path("pollution",views.pollution, name='pollution'),
    path("predict",views.predict, name='predict')
]

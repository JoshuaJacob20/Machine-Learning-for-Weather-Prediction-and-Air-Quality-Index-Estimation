import React from 'react';
import { MapContainer, TileLayer, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet'; // Importing Leaflet


const OpenWeatherMapLayer = ({ apiKey, layerName }) => {
  const map = useMap();

  const layerUrl = `https://tile.openweathermap.org/map/${layerName}/{z}/{x}/{y}.png?appid=${apiKey}`;

  const attribution = '&copy; <a href="https://openweathermap.org" target="_blank">OpenWeatherMap</a>';

  const weatherLayer = L.tileLayer(layerUrl, { attribution });

  weatherLayer.addTo(map);

  return null;
};

const WeatherMap = ({ apiKey, layerName, center, zoom }) => {
  return (
    <MapContainer center={center} zoom={zoom} style={{ height: '600px', width: '100%' }}>
      {/* <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      /> */}
      <OpenWeatherMapLayer apiKey={apiKey} layerName={layerName} />
    </MapContainer>
  );
};

export default WeatherMap;

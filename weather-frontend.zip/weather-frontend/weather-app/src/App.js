import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';
import './App.css'; // Make sure to import the CSS file

const apiKey = '0bd3c27df486a61e90b12d27d6ff4ec2'; // Replace with your actual API key
const layerName = 'temp_new'; // Replace with your preferred layer (e.g., 'clouds_new', 'precipitation_new', etc.)

const containerStyle = {
  width: '100%',
  height: '400px'
};

const center = {
  lat: -34.397,
  lng: 150.644
};

function App() {
  const [data, setData] = useState({ pollution: null, weather: null, prediction: null, dogs: [] });
  const [city, setCity] = useState('Delhi'); // Default city
  const [lat, setLat] = useState(null);
  const [lon, setLon] = useState(null);
  const [temp, setTemp] = useState(null);
  const [wind, setWind] = useState(null);
  const [humidity, setHumitidy] = useState(null);
  const [position, setPosition] = useState(null);
  const [center, setCenter] = useState(null);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyBLPg1olWp5qFyAykZbswOh7TSD-sh3MG0" // Replace with your Google Maps API Key
  });

  const fetchWeather = () => {
    axios.get(`http://13.201.221.212:8000/weather?city=${city}`)
      .then(response => {
        setData(data => ({ ...data, weather: response.data, lat: response.data.coord.lat, lon: response.data.coord.lon }))
        setLat(response.data.coord.lat);
        setLon(response.data.coord.lon);
        setCenter({ lat: parseFloat(response.data.coord.lat), lng: parseFloat(response.data.coord.lon) });

        setTemp(response.data.main.temp);
        setWind(response.data.wind.speed);
        setHumitidy(response.data.main.humidity);

        axios.get(`http://13.201.221.212:8000/pollution?lat=${response.data.coord.lat}&lon=${response.data.coord.lon}`)
          .then(response => setData(data => ({ ...data, pollution: response.data })))
          .catch(error => console.error('Error fetching pollution', error));

        if (temp && humidity && wind) {
          axios.get(`http://13.201.221.212:8000/predict?temperature=${temp}&humidity=${humidity}&wind_speed=${wind}`)
            .then(response => setData(data => ({ ...data, prediction: response.data })))
            .catch(error => console.error('Error fetching predict', error));
        }
      })
      .catch(error => console.error('Error fetching weather', error));

  };

  useEffect(() => {
    // Fetch Weather Data    
    // fetchWeather();
    getCurrentLocation();
  }, []);

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        let lat = position.coords.latitude;
        let long = position.coords.longitude;        
        console.log(position);
        setLat(lat);
        setLon(long);
        reverseGeocode(lat, long);        
      });
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  };

  const reverseGeocode = (lat, lng) => {
    const geocoder = new window.google.maps.Geocoder();
    const latlng = {
      lat: parseFloat(lat),
      lng: parseFloat(lng),
    };
    geocoder.geocode({ location: latlng }, (results, status) => {
      if (status === 'OK') {
        if (results[0]) {
          const addressComponents = results[0].address_components;
          const cityComponent = addressComponents.find(component => component.types.includes('locality'));
          const city = cityComponent ? cityComponent.long_name : 'City not found';
          setPosition({ lat, lng, city });
          setCity(city);
          fetchWeather();
        } else {
          console.log('No results found');
        }
      } else {
        console.log('Geocoder failed due to: ' + status);
      }
    });
  };

  const handleCityChange = (event) => {
    setCity(event.target.value);
  };

  const handleSearch = () => {
    // This will trigger useEffect to refetch weather data
    setCity(city);
    fetchWeather();
  };

  const onMapClick = (event) => {
    const lat = event.latLng.lat();
    const lng = event.latLng.lng();

    reverseGeocode(lat, lng);
  };

  return (
    <div>
      <div className="center-content">
        <h1>Weather Data</h1>
        <div className="input-group">
          <input type="text" value={city} onChange={handleCityChange} />
          <button onClick={handleSearch}>Search</button>
          <button onClick={getCurrentLocation}>Get Current Location</button>
        </div>
      </div>
      <div className="row">

        <div className="card">
          <h2>Weather in {city}:</h2>
          <div className="container">
            {data.weather && <p>Current Condition: {data.weather.weather[0].main}</p>}
            {data.weather && <p>Description: {data.weather.weather[0].description}</p>}
            {data.weather && <p>Temperature in kelvin: {data.weather.main.temp}<br></br>Min : {data.weather.main.temp_min}<br></br>Max : {data.weather.main.temp_max}<br></br>Feels Like : {data.weather.main.feels_like}</p>}
          </div>
        </div>

        <div className="card">
          <h2>Pollution :</h2>
          <div className="container">
            {data.pollution && data.pollution.list.map(pol => <p key={pol.dt}>co: {pol.components.co}<br></br>
              no: {pol.components.no}<br></br>
              no2: {pol.components.no2}<br></br>
              o3: {pol.components.o3}<br></br>
              so2: {pol.components.so2}<br></br>
              pm2_5: {pol.components.pm2_5}<br></br>
              pm10: {pol.components.pm10}<br></br>
              nh3: {pol.components.nh3}<br></br>
            </p>)}
          </div>
        </div>

        <div className="card">
          <h2>Air quality index :</h2>
          <div className="container">
            {data.prediction && <p >{data.prediction.predict}</p>}
          </div>
        </div>
      </div>

      <div className="row">
        <div className="full">
          <h2>Weather Map</h2>
          <div className="container">
            {isLoaded ? (
              <GoogleMap
                mapContainerStyle={containerStyle}
                center={center}
                zoom={10}
                onClick={onMapClick}
              >
                {position && <Marker position={{ lat: position.lat, lng: position.lng }} />}
              </GoogleMap>
            ) : <></>}

          </div>
        </div>
      </div>
    </div>
  );
}


export default App;